import { useState } from 'react';
import './ProductCard.css';

const ProductCard = ({ product, onAddToCart, onAddToWishlist, onViewDetails }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState(false);

  const handleWishlist = (e) => {
    e.preventDefault();
    setIsWishlisted(!isWishlisted);
    onAddToWishlist?.(product);
  };

  const handleAddToCart = (e) => {
    e.preventDefault();
    onAddToCart?.(product);
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div
      className="product-card"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onViewDetails?.(product.id)}
    >
      {/* Image Container */}
      <div className="product-image-container">
        <img src={product.image} alt={product.name} className="product-image" />

        {/* Badge */}
        {discount > 0 && <span className="product-badge">{discount}% OFF</span>}
        {product.isNew && <span className="product-badge product-badge-new">NEW</span>}

        {/* Wishlist Button */}
        <button
          className={`wishlist-btn ${isWishlisted ? 'wishlisted' : ''}`}
          onClick={handleWishlist}
          title="Add to wishlist"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
          </svg>
        </button>

        {/* Overlay Actions */}
        {isHovered && (
          <div className="product-overlay">
            <button className="action-btn" onClick={() => onViewDetails?.(product.id)}>
              Quick View
            </button>
            <button className="action-btn action-btn-cart" onClick={handleAddToCart}>
              Add to Cart
            </button>
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="product-info">
        {product.category && <span className="product-category">{product.category}</span>}
        
        <h3 className="product-name" title={product.name}>
          {product.name}
        </h3>

        {product.description && (
          <p className="product-description">{product.description}</p>
        )}

        {/* Rating */}
        {product.rating && (
          <div className="product-rating">
            <span className="stars">
              {'★'.repeat(Math.floor(product.rating))}
              {'☆'.repeat(5 - Math.floor(product.rating))}
            </span>
            <span className="rating-value">{product.rating}</span>
            {product.reviews && <span className="reviews-count">({product.reviews})</span>}
          </div>
        )}

        {/* Price */}
        <div className="product-price">
          <span className="current-price">₹{product.price.toLocaleString()}</span>
          {product.originalPrice && (
            <span className="original-price">₹{product.originalPrice.toLocaleString()}</span>
          )}
        </div>

        {/* Stock Status */}
        {product.stock !== undefined && (
          <div className={`stock-status ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
            {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductCard;