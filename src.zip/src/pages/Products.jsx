import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PRODUCTS, CATEGORIES } from '../data/products';
import ProductCard from '../components/Products/ProductCard';
import { useCart } from '../hooks';
import { useWishlist } from '../hooks';
import {
  sortProducts,
  filterByCategory,
  filterByPriceRange,
  searchProducts,
} from '../utils/utils';
import './Products.css';

const Products = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [sortBy, setSortBy] = useState('newest');
  const [priceRange, setPriceRange] = useState([0, 10000]);
  const [selectedCategory, setSelectedCategory] = useState(
    searchParams.get('category') || ''
  );

  const { addToCart } = useCart();
  const { addToWishlist } = useWishlist();

  // Get search query from URL
  const searchQuery = searchParams.get('search') || '';

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let results = [...PRODUCTS];

    // Apply search
    if (searchQuery) {
      results = searchProducts(results, searchQuery);
    }

    // Apply category filter
    if (selectedCategory) {
      results = filterByCategory(results, selectedCategory);
    }

    // Apply price filter
    results = filterByPriceRange(results, priceRange[0], priceRange[1]);

    // Apply sorting
    results = sortProducts(results, sortBy);

    return results;
  }, [searchQuery, selectedCategory, priceRange, sortBy]);

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  const handleViewDetails = (id) => {
    window.location.href = `/products/${id}`;
  };

  return (
    <div className="products-page">
      {/* Page Header */}
      <div className="page-header">
        <h1>Our Collection</h1>
        <p>Discover our exquisite range of authentic Indian sarees</p>
      </div>

      <div className="container">
        <div className="page-content">
          {/* Sidebar Filters */}
          <aside className="sidebar">
            {/* Search Filter */}
            {searchQuery && (
              <div className="filter-section">
                <h3>Search Results</h3>
                <p className="filter-subtitle">Search: "{searchQuery}"</p>
                <button
                  className="clear-filter"
                  onClick={() => setSearchParams({})}
                >
                  Clear Search
                </button>
              </div>
            )}

            {/* Category Filter */}
            <div className="filter-section">
              <h3>Categories</h3>
              <div className="filter-options">
                <label className="filter-option">
                  <input
                    type="checkbox"
                    checked={selectedCategory === ''}
                    onChange={() => handleCategoryChange('')}
                  />
                  <span>All Categories</span>
                </label>
                {CATEGORIES.map((category) => (
                  <label key={category.id} className="filter-option">
                    <input
                      type="checkbox"
                      checked={selectedCategory === category.name}
                      onChange={() => handleCategoryChange(category.name)}
                    />
                    <span>{category.name}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Price Filter */}
            <div className="filter-section">
              <h3>Price Range</h3>
              <div className="price-inputs">
                <input
                  type="number"
                  placeholder="Min"
                  value={priceRange[0]}
                  onChange={(e) =>
                    setPriceRange([parseInt(e.target.value) || 0, priceRange[1]])
                  }
                  className="price-input"
                />
                <span>-</span>
                <input
                  type="number"
                  placeholder="Max"
                  value={priceRange[1]}
                  onChange={(e) =>
                    setPriceRange([priceRange[0], parseInt(e.target.value) || 10000])
                  }
                  className="price-input"
                />
              </div>
              <div className="price-range-slider">
                <div className="price-display">
                  ₹{priceRange[0].toLocaleString()} - ₹{priceRange[1].toLocaleString()}
                </div>
              </div>
            </div>

            {/* Clear All Filters */}
            {(selectedCategory || priceRange[0] > 0 || priceRange[1] < 10000) && (
              <button
                className="btn btn-outline"
                onClick={() => {
                  setSelectedCategory('');
                  setPriceRange([0, 10000]);
                }}
                style={{ width: '100%', marginTop: 'var(--space-4)' }}
              >
                Clear All Filters
              </button>
            )}
          </aside>

          {/* Main Content */}
          <div className="content-area">
            {/* Toolbar */}
            <div className="toolbar">
              <div className="results-info">
                <p>
                  Showing <strong>{filteredProducts.length}</strong> products
                </p>
              </div>
              <div className="sort-container">
                <label htmlFor="sort">Sort by:</label>
                <select
                  id="sort"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="sort-select"
                >
                  <option value="newest">Newest First</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Highest Rating</option>
                  <option value="popular">Most Popular</option>
                </select>
              </div>
            </div>

            {/* Products Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid-4">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={addToCart}
                    onAddToWishlist={addToWishlist}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>
            ) : (
              <div className="empty-state">
                <div className="empty-state-icon">🔍</div>
                <h3>No Products Found</h3>
                <p>
                  {searchQuery
                    ? `Sorry, we couldn't find any products matching "${searchQuery}"`
                    : 'Try adjusting your filters to find what you are looking for.'}
                </p>
                <button
                  className="btn btn-primary"
                  onClick={() => {
                    setSelectedCategory('');
                    setPriceRange([0, 10000]);
                    setSearchParams({});
                  }}
                >
                  Clear Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Products;